data:extend({--  Setttings

    {--  Is Green Steel Enabled Setting   
        name="is-green-steel-enabled",
        type="bool-setting",
        setting_type="startup",
        default_value=true
    }

})