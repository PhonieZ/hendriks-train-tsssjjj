--Imports
if settings.startup["is-green-steel-enabled"].value then
    require("prototypes.item-groups")    --Imports all the custom item groups this mod adds into the game
    require("prototypes.item")           --Imports all the custom items this mod adds into the game 
    require("prototypes.recipe")         --Imports all the custom recipes this mod adds into the game
    require("prototypes.technology")     --Imports all the custom technology this mod adds into the game    
end