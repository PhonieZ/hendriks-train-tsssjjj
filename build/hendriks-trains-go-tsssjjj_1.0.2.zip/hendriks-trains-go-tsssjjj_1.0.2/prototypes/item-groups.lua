data:extend({  --Holds all groups and subgroups this mod adds

    {
        type="item-group",
        name="green-steel-group",
        order="ca",
        icon="__hendriks-trains-go-tsssjjj__/graphics/icons/green-steel.png",
        icon_mipmaps=4,
        icon_size=64
    },

    {
        type="item-subgroup",
        name="greer-intermediates",
        group="green-steel-group",
        order="ga"
    }

})