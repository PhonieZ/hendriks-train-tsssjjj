data:extend({  --This makes all the custom particles this mod adds available for use              

{--  Tsssjjj Text Particle
	affected_by_wind=false,
	animation= 
	{	
		animation_speed=0.13333333334,
		filename="__hendriks-trains-go-tsssjjj__/graphics/entity/tsssjjj-text-particle.png",
		frame_count=8,
		height=60,
		priority="high",
		width=130
	},
	color={r=1,g=1,b=1,a=1},
	duration=60,
	fade_away_duration=37,
	movement_slow_down_factor=0,
	name="tsssjjj-text-particle",
	render_layer="higher-object-above",
	show_when_smoke_off=true,
	type="trivial-smoke"
},

})