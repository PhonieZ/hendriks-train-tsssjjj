--File with all the sounds this mod adds
tsssjjj_sound=
{
	filename="__hendriks-trains-go-tsssjjj__/sound/tsssjjj-sound.ogg",
	volume=1
}

tsssjjj_trivial_smoke_effect_item=
{
	initial_height=-1,
	smoke_name="tsssjjj-text-particle",
	type="create-trivial-smoke"
}

vanilla_train_hiss=
{
    filename="__base__/sound/train-breaks.ogg",
    volume=0.3
}